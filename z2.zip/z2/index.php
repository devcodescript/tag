<!DOCTYPE html>
<html lang="en">
<head>
  <title>Select Choise</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 200px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<body>

<div class="container">
  <!--<h2>Select Your Choise</h2>-->
  <form class="form-horizontal" action="/action_page.php">
      <div class="row">
    <!--<div class="col-sm-4" style="background-color:lavender;">.col-sm-4</div>-->
    <div class="col-sm-4" ></div>
    <div class="col-sm-4" >
        <h2>Select Your Choise</h2>
        
        <a href="http://nsumbrz.com/z/registration.php" class="button">New Registration ?</a>
        <a href="http://nsumbrz.com/z/updateinfo.php" class="button">Update Journey ?</a>
        <a href="http://nsumbrz.com/z/found.php" class="button">Found Something ?</a>
    </div>
   
   
  </form>
</div>

</body>
</html>
