<?php
define('BRAND_ID','1');
define('BASE_API','http://nsusmbrz.com/public/admin/');
define('BRAND_NAME','');
define('API_BASE_URL',BASE_API.'webauth/api/');
define('COPYRIGHT','Copyright &copy; '.BRAND_NAME.' '.date('Y'));
define('BRAND_LOGO','images/sakarni_logo.png');
define('TAG_LINE','');
define('TAG_LINE_DISPLAY',false);
define('RIGHT_IMG','wallputty_logo.png');
define('IMG_WIDTH','500');
define('IMG_HEIGHT','400');
define('API_KEY','APIKEY1234');
define('SAKARNI_CARD_IMAGE','images/sakarni_card.png');



?>