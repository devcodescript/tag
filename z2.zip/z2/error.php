<?php
echo 'Some Error occured Please try again';
?>