<?php
echo 'Thanks For Update Journey Details';
?>